<?php
session_start();
include "../modelo/modelo_evidencias.php";

// Asegúrate de que el usuario esté autenticado y tenga un rol definido
if (!isset($_SESSION["SesionIn"]) || $_SESSION["SesionIn"] !== true || !isset($_SESSION["rol"])) {
    echo "<script>alert('No estás autenticado.'); location.href='../vistas/iniciar_sesion.html';</script>";
    exit();
}

$instancia = new evidencias();
$r = $instancia->registro($_POST);

// Verifica el rol del usuario
$rol = $_SESSION["rol"];

if ($r === 1) {
    if ($rol === 'administrador') {
        echo "<script>
                
                location.href='admi_consultar evidencia.php';
              </script>";
    } elseif ($rol === 'profesional') {
        echo "<script>
                alert('Registro exitoso');
                location.href='prof_consultar_evidencias.php';
              </script>";
    }
} elseif (str_contains($r, '1045')) {
    echo "<script>
            alert('Se desconectó el servidor, comuníquese con el administrador.');
            location.href='admi_consultar_evidencia.php';
          </script>";
} elseif (str_contains($r, '1062')) {
    echo "<script>
            alert('El nombre del producto ya existe, modifíquelo.');
            location.href='admi_consultar_evidencia.php';
          </script>";
} elseif (str_contains($r, '2002')) {
    echo "<script>
            alert('La conexión cayó.');
            location.href='admi_consultar_evidencia.php';
          </script>";
} else {
    echo "<script>
            alert('Error: $r');
            location.href='admi_consultar_evidencia.php';
          </script>";
}
?>
