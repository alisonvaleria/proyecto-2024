<?php
// Asegurarse de que se ha recibido un archivo a previsualizar
if (!isset($_GET['file'])) {
    echo "No se especificó ningún archivo.";
    exit();
}

$nombre_archivo = urldecode($_GET['file']);
$ruta_archivo = "../archivos_subidos/" . basename($nombre_archivo); // Usar basename para evitar traversal

// Verificar si el archivo existe
if (!file_exists($ruta_archivo)) {
    echo "El archivo no existe.";
    exit();
}

// Obtener la extensión del archivo
$extension = strtolower(pathinfo($nombre_archivo, PATHINFO_EXTENSION));

// Mostrar el enlace de vista y el botón de descarga
if ($extension === 'pdf') {
    echo '<div>';
    echo '<a href="' . htmlspecialchars($ruta_archivo) . '" target="_blank" class="btn btn-info" style="margin-right: 10px;">Ver PDF</a>';
    echo '<a href="ruta_de_tu_script_de_descarga.php?file=' . urlencode($nombre_archivo) . '" class="btn btn-primary">Descargar PDF</a>';
    echo '</div>';
    echo '<iframe src="' . htmlspecialchars($ruta_archivo) . '" width="100%" height="600px"></iframe>';
} elseif ($extension === 'csv') {
    echo '<div>';
    echo '<a href="' . htmlspecialchars($ruta_archivo) . '" target="_blank" class="btn btn-info" style="margin-right: 10px;">Ver CSV</a>';
    echo '<a href="ruta_de_tu_script_de_descarga.php?file=' . urlencode($nombre_archivo) . '" class="btn btn-primary">Descargar CSV</a>';
    echo '</div>';
    if (($handle = fopen($ruta_archivo, "r")) !== FALSE) {
        echo '<table border="1">';
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            echo "<tr>";
            foreach ($data as $cell) {
                echo "<td>" . htmlspecialchars($cell) . "</td>";
            }
            echo "</tr>";
        }
        echo '</table>';
        fclose($handle);
    } else {
        echo "No se pudo abrir el archivo CSV.";
    }
} elseif (in_array($extension, ['xls', 'xlsx'])) {
    echo '<div>';
    echo '<a href="https://docs.google.com/viewer?url=' . urlencode('http://' . $_SERVER['HTTP_HOST'] . "/archivos_subidos/" . $nombre_archivo) . '" target="_blank" class="btn btn-info" style="margin-right: 10px;">Ver Excel</a>';
    echo '<a href="ruta_de_tu_script_de_descarga.php?file=' . urlencode($nombre_archivo) . '" class="btn btn-primary">Descargar Excel</a>';
    echo '</div>';
    $url = "https://docs.google.com/viewer?url=" . urlencode('http://' . $_SERVER['HTTP_HOST'] . "/archivos_subidos/" . $nombre_archivo);
    echo '<iframe src="' . htmlspecialchars($url) . '" width="100%" height="600px"></iframe>';
} else {
    echo "Vista previa no disponible para este tipo de archivo.";
}
?>
