<?php
include "../modelo/modelo.php";

// Crear una instancia de la clase de validación
$instancia = new validacion();

// Llamar al método Acceso con los datos del formulario
$dat = $instancia->Acceso($_POST);

if (empty($dat)) {
    // Mostrar mensaje de error y redirigir si no se encuentra el usuario
    echo "<script> alert('Error al iniciar sesión'); location.href='../vistas/iniciar_sesion.html'; </script>";
} else {
    // Iniciar sesión y almacenar datos en la sesión
    session_start();
    $_SESSION["SesionIn"] = true;
    $_SESSION["rol"] = $dat[0]["Cargo"];
    $_SESSION["usuario"] = $dat[0]["ID"];
    $_SESSION["contrasena"] = $dat[0]["Contrasena"];
    // Almacenar el nombre completo del usuario en la sesión
    $_SESSION["Nombre_completo"] = $dat[0]["Nombre_completo"];

    // Redirigir según el rol del usuario
    switch ($_SESSION["rol"]) {
        case 'administrador':
            header("Location: ../vistas/admi pagina de inicio.php");
            break;
        case 'coordinador':
            header("Location: ../vistas/cordi Pagina De Inicio .php");
            break;
        case 'profesional':
            header("Location: ../vistas/prof pagina de inicio.php");
            break;
        default:
            echo "<script> alert('Rol de usuario desconocido'); location.href='../vistas/iniciar_sesion.html'; </script>";
            break;
    }
}
?>
