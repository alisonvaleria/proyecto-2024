<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Bienestar del Aprendiz</title>
    <script src="pagina de inicio.js"></script>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
        overflow: hidden; /* Evita el desplazamiento */
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            flex: 1;
        }

        .header {
            width: 100%;
            height: 12%;
        }

        .logo {
            position: relative;
            top: 0;
            left: 76%;
            transform: translate(10%, -15%);
        }

        .logo img {
            max-height: 78px;
        }
        .muneco{
            max-height: 50px;
        }
        .carpetas{
            max-width: 80px;
            max-height: 80px;
        }


        .section {
            width: 100%;
            height: 15%;
            top: 0;
            z-index: 100;
            left: 0;
            border: 1px solid black;
            background: #007832;
        }
        .container {
            width: 80%; /* Ajusta el ancho del contenedor según tus necesidades */
            background: #007832;
            text-align: center;
            margin: 20px auto; /* Margen superior e inferior de 20px, centrado horizontalmente */
            padding: auto; /* Espaciado interno */
            border: 2px solid #000000; /* Borde negro */
            box-sizing: border-box; /* Incluye el padding y el borde en el ancho total del contenedor */
            height: 10%; /* Ajusta la altura del contenedor según tus necesidades */
        }
        .button-container {
            display: flex;
            justify-content: center;
            margin: 20px;
        }

        .image-button {
            border: none;
            background: none;
            padding: 0;
            cursor: pointer;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-image {
            width: 250px; /* Ajusta el tamaño según tus necesidades */
            height: auto;
        }

        .boton {
            margin-top: 10px;
            font-size: 14px; /* Ajusta el tamaño del texto según tus necesidades */
            color: #000; /* Color del texto */
            text-align: center;
            display: block;
        }

        .div{
            width: 80%; /* Ajusta el ancho del contenedor según tus necesidades */
            text-align: center;
            margin: 20px auto; /* Margen superior e inferior de 20px, centrado horizontalmente */
            padding: auto; /* Espaciado interno */
            border: none; /* Borde negro */
            box-sizing: border-box; /* Incluye el padding y el borde en el ancho total del contenedor */
            height: 100%; /* Ajusta la altura del contenedor según tus necesidades */
        }



        footer {
            margin-top: 20px;
            color: #555;
            position: relative;
        }

        .footer-line {
            border-top: 1px solid #000000;
            margin: 20px 0;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .logo-oee {
            height: 65px; /* Ajusta la altura según sea necesario */
            position: absolute;
            left: 0;
        }

        .footer-text {
            text-align: center;
            margin-top: 10px;
            flex-grow: 1;
        }
        .action {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 120;
            }

            .action .profile {
            position: relative;
            width: 300px; /* Ancho grande para la imagen */
            height: 150px; /* Altura grande para la imagen */
            border-radius: 0%; /* Mantener forma cuadrada */
            overflow: hidden;
            cursor: pointer;
            }

            .action .profile img {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
            object-fit: cover;
            }

            .action .menu2 {
            position: absolute;
            top: 120px; /* Ajustar para que el menú esté más cerca de la imagen */
            right: -10px;
            padding: 10px 15px;
            background: #fff;
            width: 180px; /* Menú más pequeño */
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.5);
            transition: 0.5s;
            visibility: hidden;
            opacity: 0;
            }

            .action .menu2.active {
            visibility: visible;
            opacity: 1;
            top: 80px; /* Mantener el ajuste cuando el menú está activo */
            }

            .action .menu2::before {
            position: absolute;
            top: -5px;
            right: 28px;
            width: 20px;
            height: 20px;
            background: #fff;
            transform: rotate(45deg);
            }

            .action .menu2 h3 {
            width: 100%;
            text-align: center;
            font-size: 16px;
            padding: 15px 0;
            font-weight: 500;
            line-height: 1.2em;
            }

            .action .menu2 h3 span {
            font-size: 14px;
            color: #555;
            font-weight: 400;
            }

            .action .menu2 ul li {
            list-style: none;
            padding: 8px 0;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            align-items: center;
            }

            .action .menu2 ul li img {
            max-width: 20px;
            margin-right: 10px;
            opacity: 0.5;
            transition: 0.5s;
            }

            .action .menu2 ul li:hover img {
            opacity: 1;
            }

            .action .menu2 ul li a {
            display: inline-block;
            text-decoration: none;
            color: #555;
            font-weight: 500;
            transition: 0.5s;
            }

            .action .menu2 ul li:hover a {
            color: #ff0000;
            }
            
    </style>
</head>

<body>
 
        <header class="header">
            <div class="action logo">
                <div class="profile" onclick="menuToggle()">
                    <img src="img/logo_bienestarAprendiz.png">
                </div>
                <div class="menu2">
                    <ul>
                        <li><img src="img/inicio.jpg"><a href="admi pagina de inicio .php">Inicio</a></li>
                    </ul>
                    <ul>
                        <li><img src="img/log-out.png"><a href="iniciar_sesion.html">Cerrar sesion</a></li>
                    </ul>
                </div>
            </div> 
        </header>
        <section class="section">
            <center>
                <img class="muneco" src="img/muñeco.png">
                <h3>Administrador</h3>
            </center>
        </section>
        <div class="container">
            <h5>CONSULTAR INSTRUCTORES</h5>
        </div>
        <div class="div" >
            <div class="button-container">
                <button class="image-button">
                    <img src="img/carpeta.png" alt="Botón de Imagen" class="button-image">
                    <span class="button-text">instructores</span>
                </button>
            </div>



    <footer>
        <div class="footer-line"></div>
        <div class="footer-content">
            <img src="img/logo2.png" class="logo-oee">
            <center><p class="footer-text">© 2024 SENA</p></center>
        </div>
    </footer>

</body>