<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["SesionIn"]) || $_SESSION["SesionIn"] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'No estás autenticado.']);
    exit();
}

include "../modelo/conexion.php"; // Ajusta la ruta si es necesario

// Mostrar errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

$response = ['status' => 'error', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Comprobar si se ha enviado un archivo
    if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] !== UPLOAD_ERR_NO_FILE) {
        $archivo = $_FILES['archivo'];

        if ($archivo['error'] === UPLOAD_ERR_OK) {
            // Validar solo archivos PDF
            if ($archivo['type'] === 'application/pdf') {
                $directorio = "../archivos_subidos/";
                $nombreArchivoOriginal = basename($archivo['name']);
                $nombreArchivoSeguro = uniqid() . '.pdf';
                $rutaArchivo = $directorio . $nombreArchivoSeguro;

                if (move_uploaded_file($archivo['tmp_name'], $rutaArchivo)) {
                    $insert = $conexion->prepare("INSERT INTO archivos (nombre_original, nombre_seguro, ruta_archivo) VALUES (?, ?, ?)");
                    $insert->execute([$nombreArchivoOriginal, $nombreArchivoSeguro, $rutaArchivo]);

                    if ($insert->rowCount() > 0) {
                        $response = ['status' => 'success', 'message' => 'Archivo PDF subido y registrado exitosamente.'];
                    } else {
                        $response = ['status' => 'error', 'message' => 'Error al registrar el archivo en la base de datos.'];
                    }
                } else {
                    $response = ['status' => 'error', 'message' => 'Error al mover el archivo.'];
                }
            } else {
                $response = ['status' => 'error', 'message' => 'Tipo de archivo no permitido. Solo se aceptan archivos PDF.'];
            }
        } else {
            $response = ['status' => 'error', 'message' => 'Error en la subida del archivo.'];
        }
    } else {
        $response = ['status' => 'error', 'message' => 'No se ha enviado ningún archivo.'];
    }
} else {
    $response = ['status' => 'error', 'message' => 'Método no permitido.'];
}

echo json_encode($response);
?>
