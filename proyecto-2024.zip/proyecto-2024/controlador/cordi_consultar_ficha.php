<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION["SesionIn"]) || $_SESSION["SesionIn"] !== true) {
    header("Location: ../vistas/iniciar_sesion.html");
    exit();
}

// Verificar si la variable de usuario está en la sesión
if (isset($_SESSION["Nombre_completo"])) {
    $Nombre_completo = $_SESSION["Nombre_completo"];
} else {
    $Nombre_completo = 'Usuario no definido'; // O manejar el caso de manera adecuada
}

include "../modelo/conexion.php";

// Obtener la lista de archivos desde la base de datos
$consulta = $conexion->prepare("SELECT * FROM archivos");
$consulta->execute();
$archivos = $consulta->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Bienestar del aprendiz</title>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
        }

        body {
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }   

        /* Estilo general para el navbar */
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            height: 14%;
            background-color: #39A900;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 1000;
        }

        .navbar-menu {
            list-style-type: none;
            margin-left: 17%;
            padding: 0;
            display: flex;
            gap: 15px;
        }

        .navbar-menu li {
            margin: 0;
        }

        .navbar-menu a {
            text-decoration: none;
            color: white;
            font-weight: bold;
        }

        .navbar-image img {
            height: 75px;
            width: auto;
        }
        .logo-oee {
            position: absolute; /* Esto asegura que puedas posicionarlo dentro del contenedor */
            top: 10px; /* Alinea al top */
            left: 15px; /* Alinea a la izquierda */
            width: 80px; /* Ajusta el tamaño del logo a 100px de ancho */
            height: auto; /* Mantiene la proporción correcta del logo */
        }


        .sidebar {
            position: fixed;
            left: 0;
            top: 12%;
            width: 16%;
            height: 100%;
            background-color: #f6f6f6;
            padding: 20px;
            box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .sidebar-menu {
            list-style-type: none;
            margin-top: 20%;
            padding: 0;
        }

        .sidebar-menu li {
            margin-bottom: 10px;
        }

        .sidebar-link {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            display: block;
            padding: 10px;
            border-bottom: 1px solid #333;
        }

        .sidebar-link i {
            margin-right: 10px;
            font-size: 18px;
        }

        .sub-menu {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: none;
            padding-left: 20px;
        }

        .sub-menu li {
            margin-bottom: 5px;
        }

        .sub-menu a {
            text-decoration: none;
            color: #666;
        }

        .sub-menu.active {
            display: block;
        }

        .content {
        flex: 1;
        margin-top: 70px;
        margin-left: 18%;
        padding: 15px;
    }

        /* Estilos para el footer */
        footer {
        width: 100%;
        background-color: #ffffff;
        color: rgb(70, 70, 70);
        text-align: center;
        padding: 7px 0;
        position: relative;
        left: 0;
        bottom: 0;
        height: 10%;
    }

        .footer-line {
            border-top: 1px solid #666;
            margin-bottom: 10px;
        }

        .footer-text {
            margin: 0;
            font-size: 14px;
        }

        h2 {
            color: #ffffff;
        }
        .fileBox {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            width: 150px;
            text-align: center;
            margin-bottom: 15px;
        }
        .fileBox iframe {
            width: 100%;
            height: 100px; /* Altura ajustable para la vista previa */
            border: none;
            display: none; /* Ocultar por defecto */
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <ul class="navbar-menu">
            <img src="../vistas/img/nlogo.png" class="logo-oee">
            <li><a href="../vistas/cordi Pagina De Inicio .php">Inicio</a></li>
            <li><a href="../vistas/iniciar_sesion.html">Salir</a></li>
        </ul>
        <h2>Bienvenido al sistema <?php echo htmlspecialchars($Nombre_completo, ENT_QUOTES, 'UTF-8'); ?></h2>
        <div class="navbar-image">
            <img src="../vistas/img/logo_bienestarAprendiz.png">
        </div>
    </nav>

    <aside class="sidebar">
        <center><h3>Coordinador</h3></center>
        <ul class="sidebar-menu">
            <li>
                <a href="#option1" class="sidebar-link">
                    <i class="fas fa-home"></i>Usuarios y talleres
                </a>
                <ul class="sub-menu">
                    <li><a href="cordi_consultar_Talleres.php">Consultar talleres</a></li>
                    <li><a href="cordi_Consultar_Usuario.php">Consultar usuario</a></li>
                </ul>
            </li>
            <li>
                <a href="#option2" class="sidebar-link">
                    <i class="fas fa-user"></i>Fichas
                </a>
                <ul class="sub-menu">
                    <li><a href="../vistas/cordi_cargar_ficha.php">Cargar fichas </a></li>
                    <li><a href="cordi_consultar_ficha.php">Consultar fichas</a></li>
                </ul>
            </li>
            <li>
                <a href="#option3" class="sidebar-link">
                    <i class="fas fa-cog"></i> Instructores
                </a>
                <ul class="sub-menu">
                    <li><a href="../vistas/cordi_Cargar_Instructores.php">Cargar instructores  </a></li>
                    <li><a href="cordi_Consultar_Instructores.php">Consultar instructores</a></li>
                </ul>
            </li>
            <li>
                <a href="#option4" class="sidebar-link">
                    <i class="fas fa-envelope"></i> Evidencia
                </a>
                <ul class="sub-menu">
                    <li><a href="cordi_consultar_evidencia.php">Consultar evidencia</a></li>
                </ul>
            </li>
            <li>
                <a href="#option5" class="sidebar-link">
                    <i class="fas fa-info-circle"></i> Horarios 
                </a>
                <ul class="sub-menu">
                    <li><a href="../vistas/cordi_Cargar_Horarios.php">Cargar horarios</a></li>
                    <li><a href="cordi_Consultar_Horarios.php">Consultar Horarios</a></li>
                </ul>
            </li>
        </ul>
    </aside>
    <div class="content">
    <?php if (empty($archivos)): ?>
        <p>No se encontraron archivos.</p>
    <?php else: ?>
        <div id="fileContainer">
            <?php foreach ($archivos as $archivo): ?>
                <?php 
                $nombreArchivo = htmlspecialchars($archivo['nombre_original']);
                $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
                $rutaArchivo = "../archivos_subidos/" . urlencode($archivo['nombre_seguro']);
                ?>

                <!-- Caja del archivo -->
                <div class="fileBox">
                    <p><?php echo $nombreArchivo; ?></p>
                    
                    <?php if ($extension === 'pdf'): ?>
                        <iframe src="<?php echo $rutaArchivo; ?>" id="preview-<?php echo $archivo['nombre_seguro']; ?>" style="display:none;"></iframe>
                    <?php endif; ?>
                    
                    <a href="descargar_archivo.php?file=<?php echo urlencode($archivo['nombre_seguro']); ?>" target="_blank">Descargar</a>
                    <a href="vista_previa.php?file=<?php echo urlencode($archivo['nombre_seguro']); ?>" target="_blank">Vista previa</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

    <footer>
    <div class="footer-line"></div>
        <p class="footer-text">Servicio Nacional de Aprendizaje SENA - Centro de Gestión de Mercados, Logística y Tenologías de la Información - Regional Distrito Capital </p>
        <br><p class="footer-text">Dirección: Cl 52 N° 13 65 -Telefono: +(57) 601 594 1301 </p></br>
        
    </footer>

    <!-- JavaScript para manejar la expansión de subopciones -->
    <script>

function togglePreview(fileName) {
    const previewDiv = document.getElementById(`preview-${fileName}`);
    if (previewDiv) {
        previewDiv.style.display = previewDiv.style.display === 'none' || !previewDiv.style.display ? 'block' : 'none';
    }
}



        document.querySelectorAll('.sidebar-link').forEach(link => {
            link.addEventListener('click', (event) => {
                const subMenu = link.nextElementSibling;
                if (subMenu) {
                    subMenu.classList.toggle('active');
                    event.preventDefault();
                }
            });
        });
    </script>
</body>

</html>
