<?php
class validacion
{
    private $usuario;
    private $contrasena;

    public function Acceso($datos)
    {
        // Obtener datos del formulario
        $this->usuario = $datos["txt1"];
        $this->contrasena = $datos["txt2"];
        include "conexion.php";

        // Preparar y ejecutar la consulta
        $consulta = $conexion->prepare("CALL validacion(?, ?)");
        $consulta->bindParam(1, $this->usuario);
        $consulta->bindParam(2, $this->contrasena);
        $consulta->execute();
        
        // Obtener los resultados
        $tabla = $consulta->fetchAll();

        // Depuración: Imprimir los resultados obtenidos
        var_dump($tabla);

        // Retornar los resultados si hay datos, sino un array vacío
        return (sizeof($tabla) === 1) ? $tabla : [];
    }
}

class usuario
{
    private $tipo_documento;
    private $ID;
    private $Nombre_completo;
    private $Rh;
    private $Telefono;
    private $Direccion;
    private $cargo;
    private $contrasena;
    private $Correo;


    public function registro($datos)
 {
    try {


        $this->tipo_documento = $datos['txt1'];
        $this->ID = $datos['txt2'];
        $this->Nombre_completo = $datos['txt3'];
        $this->Rh = $datos['txt4'];
        $this->Telefono = $datos['txt5'];
        $this->Direccion = $datos['txt6'];
        $this->Cargo = $datos['txt7'];
        $this->contrasena = $datos['txt9'];
        $this->Correo = $datos['txt10'];

        

        include "conexion.php";
        $consulta = $conexion->prepare("CALL registro_usuario(?,?,?,?,?,?,?,?,?)");
        $consulta->bindParam(1, $this->tipo_documento);
        $consulta->bindParam(2, $this->ID);
        $consulta->bindParam(3, $this->Nombre_completo);
        $consulta->bindParam(4, $this->Rh);
        $consulta->bindParam(5, $this->Telefono);
        $consulta->bindParam(6, $this->Direccion);
        $consulta->bindParam(7, $this->Cargo);
        $consulta->bindParam(8, $this->contrasena);
        $consulta->bindParam(9, $this->Correo);
        $consulta->execute();

        return 1;
    } catch (Exception $a) {
        return $a;
        }
    }

    
    public function consulta_general()
    {
        include "conexion.php";
        $consulta = $conexion->prepare("CALL consultag_usuario");
        $consulta->execute();
        $tabla = $consulta->fetchALL(PDO::FETCH_ASSOC);
        return $tabla;
    }

    public function Consulta_especifica($dat)
    {
        include "conexion.php";
        $Consulta_especifica = $conexion->prepare("CALL ConsultarUsuario(?)");
        $Consulta_especifica->bindParam(1, $dat['txt2']);
        $Consulta_especifica->execute();
        $mani = $Consulta_especifica->fetch();
        return $mani;
    }
    
    public function actualizar($datos)
    {
        $this->tipo_documento = $datos['txt1'];
        $this->ID = $datos['txt2'];
        $this->Nombre_completo = $datos['txt3'];
        $this->Rh = $datos['txt4'];
        $this->Telefono = $datos['txt5'];
        $this->Direccion = $datos['txt6'];
        $this->Cargo = $datos['txt7'];
        $this->Correo = $datos['txt10'];

        

        include "conexion.php";
        $consulta = $conexion->prepare("CALL actualizar_usuario(?,?,?,?,?,?,?,?)");
        $consulta->bindParam(1, $this->tipo_documento);
        $consulta->bindParam(2, $this->ID);
        $consulta->bindParam(3, $this->Nombre_completo);
        $consulta->bindParam(4, $this->Rh);
        $consulta->bindParam(5, $this->Telefono);
        $consulta->bindParam(6, $this->Direccion);
        $consulta->bindParam(7, $this->Cargo);
        $consulta->bindParam(8, $this->Correo);
        $consulta->execute();      
        return 1;
    }

    public function eliminar($datos)
    {
        include "conexion.php";
        $this->ID = $datos['txt2'];
        $consulta = $conexion->prepare("CALL eliminar_usuario(?)");
        $consulta->bindParam(1, $this->ID);
        $consulta->execute();
        return 1;
    }

    public function buscarPorNombre($nombre) {
        include "conexion.php"; // Reutilizar la conexión existente
        $sql = "SELECT * FROM usuario WHERE Nombre_completo LIKE ?";
        $stmt = $conexion->prepare($sql);
        $param = "%$nombre%";
        $stmt->bindParam(1, $param);
        $stmt->execute();
        $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $resultado;
    }
    


    
    
}


?>