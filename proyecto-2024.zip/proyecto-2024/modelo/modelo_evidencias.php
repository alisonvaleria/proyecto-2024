<?php


class evidencias
{
    private $nombre_taller;
    private $profesional1;
    private $profesional2;
    private $ficha;
    private $fecha_hora;
    private $enlaceimagen;
    


    public function registro($datos)
 {
    try {
        $this->nombre_taller = $datos['txt1'];
        $this->profesional1 = $datos['txt2'];
        $this->profesional2 = $datos['txt3'];
        $this->ficha = $datos['txt4'];
        $this->fecha_hora = $datos['txt5'];
        $this->enlaceimagen = $datos['txt6'];
   

        

        include "conexion.php";
        $consulta = $conexion->prepare("CALL registro_evidencia(?,?,?,?,?,?)");
        $consulta->bindParam(1, $this->nombre_taller);
        $consulta->bindParam(2, $this->profesional1);
        $consulta->bindParam(3, $this->profesional2);
        $consulta->bindParam(4, $this->ficha);
        $consulta->bindParam(5, $this->fecha_hora);
        $consulta->bindParam(6, $this->enlaceimagen);

        $consulta->execute();

        return 1;
    } catch (Exception $a) {
        return $a;
        }
    }


    public function consulta_general()
    {
        include "conexion.php";
        $consulta = $conexion->prepare("CALL consultag_evidencia");
        $consulta->execute();
        $tabla = $consulta->fetchALL(PDO::FETCH_ASSOC);
        return $tabla;
    }

    public function Consulta_especifica($dat)
    {
        include "conexion.php";
        $Consulta_especifica = $conexion->prepare("CALL Consultarevidencia(?)");
        $Consulta_especifica->bindParam(1, $dat['txt1']);
        $Consulta_especifica->execute();
        $mani = $Consulta_especifica->fetch();
        return $mani;
    }


    public function actualizar($datos)
    {
        $this->nombre_taller = $datos['txt1'];
        $this->profesional1 = $datos['txt2'];
        $this->profesional2 = $datos['txt3'];
        $this->ficha = $datos['txt4'];
        $this->fecha_hora = $datos['txt5'];
        $this->enlaceimagen = $datos['txt6'];


        

        include "conexion.php";
        $consulta = $conexion->prepare("CALL actualizar_evidencia(?,?,?,?,?,?)");
        $consulta->bindParam(1, $this->nombre_taller);
        $consulta->bindParam(2, $this->profesional1);
        $consulta->bindParam(3, $this->profesional2);
        $consulta->bindParam(4, $this->ficha);
        $consulta->bindParam(5, $this->fecha_hora);
        $consulta->bindParam(6, $this->enlaceimagen);
        $consulta->execute();      
        return 1;
    }

    public function eliminar($datos)
    {
        include "conexion.php";
        $this->nombre_taller = $datos['txt1'];
        $consulta = $conexion->prepare("CALL eliminar_evidencias(?)");
        $consulta->bindParam(1, $this->ID_evidencias);
        $consulta->execute();
        return 1;
    }

}

?>