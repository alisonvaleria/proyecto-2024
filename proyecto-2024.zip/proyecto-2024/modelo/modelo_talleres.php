<?php


class talleres
{
    private $Nombre_taller;
    private $profesional1;
    private $profesional2;
    private $numeroficha;
    private $sede;
    private $duracion;
    private $fecha_hora;
    private $tematica;
    private $nombre_instructor;
    private $correo_instructor;


        public function registro($datos)
        {
        try {

            $this->Nombre_taller = $datos['txt1'];
            $this->profesional1 = $datos['txt2'];
            $this->profesional2 = $datos['txt3'];
            $this->numeroficha = $datos['txt4'];
            $this->sede = $datos['txt5'];
            $this->duracion = $datos['txt6'];
            $this->fecha_hora = $datos['txt7'];
            $this->tematica = $datos['txt8'];
            $this->nombre_instructor = $datos['txt11'];
            $this->correo_instructor = $datos['txt12'];

            

            include "conexion.php";
            $consulta = $conexion->prepare("CALL registro_talleres(?,?,?,?,?,?,?,?,?,?)");
            $consulta->bindParam(1, $this->Nombre_taller);
            $consulta->bindParam(2, $this->profesional1);
            $consulta->bindParam(3, $this->profesional2);
            $consulta->bindParam(4, $this->numeroficha);
            $consulta->bindParam(5, $this->sede);
            $consulta->bindParam(6, $this->duracion);
            $consulta->bindParam(7, $this->fecha_hora);
            $consulta->bindParam(8, $this->tematica);
            $consulta->bindParam(9, $this->nombre_instructor);
            $consulta->bindParam(10, $this->correo_instructor);
            $consulta->execute();

            return 1;
        } catch (Exception $a) {
            return $a;
            }
        }

        public function consulta_general()
        {
            include "conexion.php";
            $consulta = $conexion->prepare("CALL consultag_talleres");
            $consulta->execute();
            $tabla = $consulta->fetchALL(PDO::FETCH_ASSOC);
            return $tabla;
        }

        public function Consulta_especifica($dat)
        {
            include "conexion.php";
            $Consulta_especifica = $conexion->prepare("CALL Consultartaller(?)");
            $Consulta_especifica->bindParam(1, $dat['txt1']);
            $Consulta_especifica->execute();
            $mani = $Consulta_especifica->fetch();
            return $mani;
        }
        

        public function actualizar($datos)
        {
            $this->Nombre_taller = $datos['txt1'];
            $this->profesional1 = $datos['txt2'];
            $this->profesional2 = $datos['txt3'];
            $this->numeroficha = $datos['txt4'];
            $this->sede = $datos['txt5'];
            $this->duracion = $datos['txt6'];
            $this->fecha_hora = $datos['txt7'];
            $this->tematica = $datos['txt8'];
            $this->nombre_instructor = $datos['txt11'];
            $this->correo_instructor = $datos['txt12'];

            

            include "conexion.php";
            $consulta = $conexion->prepare("CALL actualizar_talleres(?,?,?,?,?,?,?,?,?,?)");
            $consulta->bindParam(1, $this->Nombre_taller);
            $consulta->bindParam(2, $this->profesional1);
            $consulta->bindParam(3, $this->profesional2);
            $consulta->bindParam(4, $this->numeroficha);
            $consulta->bindParam(5, $this->sede);
            $consulta->bindParam(6, $this->duracion);
            $consulta->bindParam(7, $this->fecha_hora);
            $consulta->bindParam(8, $this->tematica);
            $consulta->bindParam(9, $this->nombre_instructor);
            $consulta->bindParam(10, $this->correo_instructor);
            $consulta->execute();
            return 1;
    }   
    public function eliminar($datos)
    {
        include "conexion.php";
        $this->Nombre_taller = $datos['txt1'];
        $consulta = $conexion->prepare("CALL eliminar_talleres(?)");
        $consulta->bindParam(1, $this->Nombre_taller);
        $consulta->execute();
        return 1;
    }

 
}
 ?>