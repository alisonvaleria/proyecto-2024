<?php

$conexion= new PDO("mysql:host=localhost;dbname=proyecto_2024","root");



?>